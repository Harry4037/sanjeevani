define({
  "name": "Sanjeevani API's",
  "version": "1.0.0",
  "description": "",
  "title": "Sanjeevani apiDoc",
  "url": "http://sanjeevani.dbaquincy.com/apidoc",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-10-17T13:04:12.669Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
